# -*- coding: utf-8 -*-
from .SegModel import SegModel
from .PosModel import PosModel
from .NerModel import NerModel
from .ParserModel import ParserModel
import os

# cut = SegModel().cut
# pos = PosModel().pos
ner = NerModel().ner
# parser = ParserModel().parser


