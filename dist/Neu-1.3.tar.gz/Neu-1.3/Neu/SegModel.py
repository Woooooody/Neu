

class SegModel():
    def __init__(self):
        pass

    def cut(self):
        print("cut le")