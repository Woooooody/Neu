

class PosModel:
    def __init__(self):
        pass

    def pos(self):
        pass


